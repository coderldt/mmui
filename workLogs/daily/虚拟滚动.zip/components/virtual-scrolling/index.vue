<template>
	<scroll-view class="container" scroll-y :style="{ 'height': boxH + 'px' }" @scroll="handleScroll">
	
		<div class="scroll-box"  :style="{ 'height': allHeight + 'px' }">
			<div  class="list-wrap" :style="{ 'transform': 'translateY(' + offsetY + 'px)' }">
				<slot></slot>
			</div>
		</div>
		
		
	</scroll-view>
</template>

<script>
	export default {
		props: {
			// 外层盒子高度
			boxH: {
				type: Number,
				required: true,
			},
			// 每个元素的高度
			itemH: {
				type: Number,
				required: true
			},
			// 列表数据
			list: {
				type: Array,
				default: [],
				required: true
			},
			// 上下多出5个列表项用于加载缓存
			cacheNum: {
				type: Number,
				default: 5
			},
			listNum: {
				type: Number,
				required: true
			}
		},
		data() {
			return {
				nowList: [], // 目前显示列表
				lastUpdateTime: 0,
				offsetY: 0
			}
		},
		computed: {
			allHeight() {
			  return this.listNum * this.itemH
			},
			pageNum() {
			  return Math.ceil(this.boxH / this.itemH) + this.cacheNum
			}
		},
		watch: {
			boxH() {
				console.log('初始化')
			
				this.init()
			}
		},
		methods: {
			init() {
				this.nowList = this.list.slice(0, this.pageNum + 1)
				this.$emit('setList', this.nowList)
			},
			handleScroll(e) {
				const scrollTop = e.detail.scrollTop
				
				console.log(scrollTop)
				// 1.保持显示区域一直在屏幕上
				this.offsetY = scrollTop - (scrollTop % this.itemH)
						
				// 2.计算卷起多少个，替换更新
				let startIndex = Math.floor(scrollTop / this.itemH)
				let endIndex = startIndex + this.pageNum
				
				// 3.当向上卷起的数量超过缓存个数的时候，上面缓存设置,扩大显示区域
				// 卷起的高度要去除缓存部分,同时修改起始位置
				if(startIndex > this.cacheNum) {
					this.offsetY -= this.cacheNum * this.itemH
				    startIndex = startIndex - this.cacheNum
				}
				
				// 4 更新当前显示内容
				this.nowList = this.list.slice(startIndex, startIndex + this.pageNum)
				
				this.$emit('setList', this.nowList)
			}
		}
	}
</script>

<style scoped lang="scss">
	
	* {
		padding: 0;
		margin: 0;
	}
	.list-wrap {
		width: 100%;
		height: 100%;
	}
	.list-item {
		width: 100vw;
		height: 100rpx;
		list-style: none;
		border: 1px solid red;
	}
</style>