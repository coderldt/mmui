# virtual-scrolling

#### 介绍
基于vue开发的虚拟滚动列表

#### 使用说明

1. 使用说明
```
<virtual-scrolling :boxH="boxH" :itemH="itemH" :listNum="listNum" :list="list" @setList="setList">
	<!-- 可替换成其他组件 -->
	<div v-for="item,index in nowList" :key="index"  class="list-item">
		{{item}}
	</div>
</virtual-scrolling>
```
下载好组件后引入组件，换成你的列表组件就ok了