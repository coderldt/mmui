<template>
	<view class="container">
		<div class="virtual-scroll-wrap" ref="virtualScrollWrapRef">
			<virtual-scrolling :boxH="boxH" :itemH="itemH" :listNum="listNum" :list="list" @setList="setList">
				<!-- 可替换成其他组件 -->
				<div v-for="item,index in nowList" :key="index"  class="list-item">
					{{item}}
				</div>
			</virtual-scrolling>
		</div>
	</view>
</template>

<script>
	import VirtualScrolling from '@/components/virtual-scrolling/index.vue'
	export default {
		components: {
			VirtualScrolling
		},
		data() {
			return {
				// 外层盒子高度
				boxH: 0,
				// 每个元素的高度
				itemH: 100,
				// 数据源
				list: [],
				nowList: [],
				
				listNum: 1000,
			}
		},
		onLoad() {
			this.$nextTick(() => {
				this.boxH = this.$refs.virtualScrollWrapRef.offsetHeight
				this.initList()
				console.log(this.$refs.virtualScrollWrapRef.offsetHeight)
			})
		},
		methods: {
			setList(list) {
				
				this.nowList = list
			},
			initList() {
				// 模拟整个列表元素
				const list = []
				for(let i =0;i<this.listNum; i++) {
					list.push(i)
				}
				this.list = list
			},
		}
	}
</script>

<style scoped lang="scss">
.virtual-scroll-wrap {
	width: 100%;
	height: 100vh;
	
	.list-item {
		width: 100vw;
		height: 200rpx;
		list-style: none;
		border: 1px solid red;
	}
}
</style>
