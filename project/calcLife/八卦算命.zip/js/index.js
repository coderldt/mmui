new Vue({
  el: "#app",
  data: function () {
    return {
      date: '',
      week: '',
      lunarDate: '',
      // 生肖
      zodiacConfig: {
        0: "鼠",
        1: "牛",
        2: "虎",
        3: "兔",
        4: "龙",
        5: "蛇",
        6: "马",
        7: "羊",
        8: "猴",
        9: "鸡",
        10: "狗",
        11: "猪"
      },
      chineseZodiac: "",
      lunarDateJiaZi: [],

      aaa: '',
      options: [{
        value: 'A',
        label: 'A'
      }, {
        value: 'B',
        label: 'B'
      }],
      datas: [],
      currentPage: 1,
      currentSizes: 40,
      maxPage: 5,
      resOption: ['AAB', 'ABA', 'BAA'],
      isLoading: true,
      count: {
        'AAA': {
          value: 0,
          children: ['AAB', 'AAA'],
          noValue: 0
        },
        'AAB': {
          value: 0,
          children: ['ABA', 'ABB'],
          noValue: 0
        },
        'ABA': {
          value: 0,
          children: ['BAA', 'BAB'],
          noValue: 0
        },
        'ABB': {
          value: 0,
          children: ['BBA', 'BBB'],
          noValue: 0
        },
        'BAA': {
          value: 0,
          children: ['AAB', 'AAA'],
          noValue: 0
        },
        'BAB': {
          value: 0,
          children: ['ABA', 'ABB'],
          noValue: 0
        },
        'BBA': {
          value: 0,
          children: ['BAA', 'BAB'],
          noValue: 0
        },
        'BBB': {
          value: 0,
          children: ['BBA', 'BBB'],
          noValue: 0
        },
      }
    };
  },
  created() {
    this.isLoading = true
    this.lunarDateJiaZi = new Lunar(new Date()).gz

    this.date = dayjs().format("YYYY年MM月DD日")
    this.week = dayjs().day()
    let date = new Date()
    this.lunarDate = getLunar(date)
    this.chineseZodiac = this.zodiacConfig[((dayjs().year() - 1900) % 12)]

    const storageData = localStorage.getItem('datas')
    if (storageData) {
      this.datas = JSON.parse(storageData)
      this.statistics()
    } else {
      this.reset()
    }

    window.addEventListener("beforeunload", this.beforeunloadHandler)

    this.isLoading = false
  },
  computed: {
    getCurrentData() {
      if (this.datas.length === 0) {
        return []
      }

      const currentCol = (this.currentPage - 1) * this.currentSizes
      return this.datas.slice(currentCol, currentCol + this.currentSizes)
    },
    getPre() {
      return (this.currentPage - 1) * this.currentSizes
    },
    getNext() {
      return this.getPre + this.currentSizes
    },
  },
  methods: {
    prex() {
      if (this.currentPage <= 1) {
        this.currentPage = 1
      } else {
        this.currentPage -= 1
      }
    },
    next() {
      if (this.currentPage >= this.maxPage) {
        this.currentPage = this.maxPage
      } else {
        this.currentPage += 1
      }
    },
    handleCurrentChange(val){
      this.currentPage = val
    },
    statistics() {
      this.resetCount()
      let result = ''
      this.datas.forEach(item => {
        item.forEach(i => {
          if (i.value && i.value !== '暂停') {
            result += i.value
          }
          // if (i.value === '暂停' && i.value) {
          //   result += i.value
          // } else {
          //   result += ' '
          // }
        })
      })
      console.log(result, 'result');

      if (result.length <= 2) {
        Object.keys(this.count).forEach(key => {
          this.count[key].noValue = result.length
        })
      } else {
        Object.keys(this.count).forEach(key => {
          this.count[key].noValue = 2
        })
        for (let i = 0; i < result.length - 2; i++) {
          console.log();
          const currentRes = result.slice(i, i + 3)
          if (this.count[currentRes]) {
            this.count[currentRes].value += 1
            this.count[currentRes].noValue = 0
            Object.keys(this.count).forEach(key => {
              if (key !== currentRes) {
                this.count[key].noValue += 1
              }
            })
          }
        }
      }
    },
    beforeunloadHandler() {
      localStorage.setItem('datas', JSON.stringify(this.datas))
    },
    reset() {
      this.currentPage = 1
      this.datas = []
      for (let index = 1; index <= 200; index++) {
        this.datas.push([{ value: '', desc: '' }, { value: '', desc: '' }, { value: '', desc: '' }, { value: '', desc: '' }, { value: '', desc: '' }, { value: '', desc: '' }])
      }
      this.resetCount()
    },
    resetCount() {
      this.count = {
        'AAA': {
          value: 0,
          children: ['AAB', 'AAA'],
          noValue: 0
        },
        'AAB': {
          value: 0,
          children: ['ABA', 'ABB'],
          noValue: 0
        },
        'ABA': {
          value: 0,
          children: ['BAA', 'BAB'],
          noValue: 0
        },
        'ABB': {
          value: 0,
          children: ['BBA', 'BBB'],
          noValue: 0
        },
        'BAA': {
          value: 0,
          children: ['AAB', 'AAA'],
          noValue: 0
        },
        'BAB': {
          value: 0,
          children: ['ABA', 'ABB'],
          noValue: 0
        },
        'BBA': {
          value: 0,
          children: ['BAA', 'BAB'],
          noValue: 0
        },
        'BBB': {
          value: 0,
          children: ['BBA', 'BBB'],
          noValue: 0
        },
      }
    }
  },
  destroyed() {
    window.removeEventListener("beforeunload", this.beforeunloadHandler);
  },
});